# Rising Sea v1.65

Minecraft Java 26.3 / Fabric; JDK 25 fuer den Build.

## Funktionen

- LAYERS, REALISTIC, TSUNAMI (EXPERIMENTAL) mit globalem Zielwasserstand, manueller Zielhoehe und Chunk-Verarbeitung.
- Feste Anstiegsintervalle in Sekunden oder optional ein **zufaelliges Intervall nach Minecraft-Tagen** (`randomSchedule`, `randomMinDays`, `randomMaxDays`). Nur LAYERS/REALISTIC; TSUNAMI verwendet weiterhin `tsunamiIntervalDays`. Ein Minecraft-Tag entspricht 24.000 Server-Ticks. Der ausgeloste Zeitpunkt wird in der Weltdaten-Datei gespeichert.
- Optional `waitForChunkPass`: automatischen Anstieg erst freigeben, wenn die laufende Chunk-Warteschlange abgearbeitet ist. Bei grossen Radien kann das die Flut stark verzoegern; standardmaessig **aus**. REALISTIC bleibt eine vereinfachte Wasser-Ausbreitung, kein physikalischer Wellensimulator.
- Chunk-Raender werden beim Fuellen vor dem Chunk-Innenbereich bearbeitet. Das kann sichtbare Kanten verringern, verhindert Minecraft-Fluessigkeitsspruenge nicht sicher.
- `/risingsea status` zeigt Zielpegel, offene Chunks und seit Serverstart platzierte Wasserbloecke. `debug` kann als Diagnose-Einstellung geschaltet werden.
- Lokale Standardkonfiguration ist auch im Mod-Menu-Hauptmenue anzeigbar und dort speicherbar. Im Spiel sind die **Serverwerte verbindlich**; auf dedizierten Servern wirken lokale Hauptmenue-Defaults nicht.
- Bei steigendem Meeresspiegel werden ausschliesslich geeignete bestehende Boote angehoben; beim Absenken uebernimmt Vanilla die Bootsphysik. Andere Entities werden nicht extra versetzt.

## Konsolenbeispiele

```text
risingsea set randomschedule true
risingsea set randommindays 1
risingsea set randommaxdays 5
risingsea set waitscan true
risingsea set debug true
risingsea status
risingsea setlevel 75
risingsea mode tsunami
risingsea set tsunamidays 3
```

## Build

Unter Windows CMD im Ordner mit `build.gradle`:

```bat
set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-25.0.5.8-hotspot" && set "PATH=C:\Program Files\Eclipse Adoptium\jdk-25.0.5.8-hotspot\bin;%PATH%" && gradle --stop && gradle clean build
```

Erwartete JAR bei erfolgreichem Build: `build/libs/risingsea-6.4.jar`.

## Test und Grenzen

Dies ist **Quellcode** und keine getestete JAR. Vor dem Einsatz eine Welt sichern. Globaler Zielwert heisst nicht, dass alle ungeladenen Chunks sofort veraendert werden. Das Rueckbau-Ledger erfasst nur vom Mod gesetzte Wasserbloecke. TSUNAMI und Vanilla-Fluessigkeitsphysik koennen Wasser ueber die gespeicherten Positionen hinaus verteilen. Die experimentelle Wellenbereinigung ist weiterhin nicht zuverlaessig vollstaendig. Falling Sea und Rising Sea nicht gleichzeitig in derselben Welt zum Bearbeiten von Wasserstaenden einsetzen.

Die Basis fuer die Chunk-Rand-Reihenfolge, Scan-Barriere und persistente Random-Intervalle wurde anhand der vom Nutzer bereitgestellten Falling Sea v1.22-Quellen angepasst. Die Funktionen werden nicht 1:1 uebertragen, weil Entfernen von Wasser und Hinzufuegen von Wasser unterschiedliche Nebenwirkungen erzeugen.


## Languages / Sprachen
GUI, HUD effect, and key server/chat messages are translated to English and German
through `assets/risingsea/lang/en_us.json` and `de_de.json`. Language follows Minecraft client settings.

## Rising Sea status-effect-style HUD
A compact effect-like countdown appears in the upper right during the final warning seconds
when a rise is pending, flooding is active and chunk processing is ready. This is a HUD element,
not a potion effect; it does not alter player attributes. It is updated via server snapshots.

## Icon
`assets/risingsea/icon.png`: upward arrows above seawater, opposite direction from Falling Sea.

## Countdown (v1.65)

- Only the upper-right effect tile is shown; the redundant actionbar countdown was removed.
- `countdownLastSeconds` sets the *start of the warning window* (0-60 seconds), not the interval between events.
- `intervalSeconds` governs regular rise in LAYERS/REALISTIC. TSUNAMI uses `tsunamiIntervalDays` (Minecraft days); 0 means manual only.
- Manual-only tsunami reports `manual` in `/risingsea status` and never displays an absurd countdown.
- While the next rising step is waiting for a chunk pass, the effect tile is suppressed to avoid a frozen countdown.

For 60 seconds of advance notice, configure `countdownLastSeconds=60`. To trigger a tsunami automatically use `tsunamiIntervalDays>=1`; normal `intervalSeconds=60` does not override the tsunami day timer.

## Tsunami-Wellenfront (v1.65)

Der Tsunami wird als wandernde ringfoermige Front mit Partikeln und einer begrenzten Zahl zusaetzlicher temporaerer Wasserquellen simuliert. Die Quellen werden nur in bereits geladenen Chunks und nur in Luftpositionen oberhalb des aktuellen Meeresspiegels gesetzt. Ein zeitbasierter Bereinigungsauftrag soll sie nach dem Wellendurchgang entfernen. Bei einem Crash werden aufgezeichnete Quellen beim naechsten Weltstart erneut zur Bereinigung eingeplant.

**Wichtig:** Minecraft kann aus den temporaeren Wasserquellen weiteres, nicht protokolliertes Fliesswasser erzeugen. Die Ruecknahme ist daher nur ein Best-Effort-Verfahren und **keine Garantie**, dass der Ursprungszustand vollstaendig wiederhergestellt wird. Die Wellenfront ist keine vollstaendige Stroemungs- oder Physiksimulation. In aelteren Welten verbliebenes Wasser aus frueheren Versionen kann nicht automatisch identifiziert werden. Verwende eine frische, gesicherte Testwelt.

## Tsunami (experimental) in v1.65

- `permanentSeaLevelRise=false` (`/risingsea set permanent false`): traveling temporary wave with no persistent sea-level change. The ordinary base sea level remains unchanged.
- `permanentSeaLevelRise=true`: traveling wave plus persistent global target rise.
- `liftBoatsWithSeaLevel=true` (`/risingsea set boatlift true`): lift eligible boats, with passengers, once when the normal sea target rises. This does not move mobs, dropped items, or swimmers. Turning this off disables the boat lift. Lowering remains under vanilla buoyancy/gravity control for safety.
- A capped set of temporary wave-water blocks is recorded in `risingsea-temporary-wave.dat.gz`. Cleanup is retried when chunks reload; old records from a crash are restored and cleaned. Natural water and structures are not intentionally overwritten. Minecraft fluid propagation can still leave untracked flowing water. **This is experimental and does not guarantee perfect rollback**. Use a disposable test world.
- Tsunami intervals use `tsunamiIntervalDays`, with `0` meaning manual only.
