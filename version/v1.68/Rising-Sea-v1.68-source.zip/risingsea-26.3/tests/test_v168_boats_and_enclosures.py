import pathlib
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCE=(ROOT/'src/main/java/de/risingsea/RisingSea.java').read_text()
POLICY=(ROOT/'src/main/java/de/risingsea/BoatLiftPolicy.java').read_text()

class Regression(unittest.TestCase):
    def test_boat_relocation_above_water_top(self):
        self.assertIn('save.level + 1.08', SOURCE)
        self.assertIn('BlockPos belowTarget = BlockPos.containing(boat.getX(), save.level, boat.getZ())', SOURCE)
        self.assertIn('world.noCollision(boat, boat.getBoundingBox().move(', SOURCE)
    def test_rescue_covers_air_pocket(self):
        body=SOURCE.split('private void rescueSubmergedBoats(',1)[1].split('private boolean isAtWave',1)[0]
        self.assertNotIn('world.getFluidState(boatWater)', body)
        self.assertIn('world.getBlockState(surface).is(Blocks.WATER)', body)
        self.assertIn('!world.getBlockState(surface.above()).isAir()', body)
        self.assertIn('boat.getPassengers().isEmpty()', body)
    def test_solid_roof_stays_dry(self):
        self.assertIn('boolean exposed = level.canSeeSky(pos);', SOURCE)
        self.assertIn('boolean fill = exposed || (cfg.floodCaves && connected);', SOURCE)
        self.assertNotIn('boolean fill = !"REALISTIC".equals(cfg.floodMode) || hasWetNeighbor(level, pos);', SOURCE)
    def test_no_generic_entity_teleports(self):
        self.assertNotIn('ItemEntity.class',SOURCE)
    def test_version(self):
        self.assertIn('mod_version=1.68',(ROOT/'gradle.properties').read_text())

if __name__ == '__main__': unittest.main()
