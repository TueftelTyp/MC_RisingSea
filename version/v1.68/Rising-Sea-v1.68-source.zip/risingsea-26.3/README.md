# Rising Sea v1.68

Minecraft Java 26.3 / Fabric; JDK 25 fuer den Build.

## Funktionen

- LAYERS, REALISTIC, TSUNAMI (EXPERIMENTAL) mit globalem Zielwasserstand, manueller Zielhoehe und Chunk-Verarbeitung.
- Feste Anstiegsintervalle in Sekunden oder optional ein **zufaelliges Intervall nach Minecraft-Tagen** (`randomSchedule`, `randomMinDays`, `randomMaxDays`). Nur LAYERS/REALISTIC; TSUNAMI verwendet weiterhin `tsunamiIntervalDays`. Ein Minecraft-Tag entspricht 24.000 Server-Ticks. Der ausgeloste Zeitpunkt wird in der Weltdaten-Datei gespeichert.
- Optional `waitForChunkPass`: automatischen Anstieg erst freigeben, wenn die laufende Chunk-Warteschlange abgearbeitet ist. Bei grossen Radien kann das die Flut stark verzoegern; standardmaessig **aus**. REALISTIC bleibt eine vereinfachte Wasser-Ausbreitung, kein physikalischer Wellensimulator.
- Chunk-Raender werden beim Fuellen vor dem Chunk-Innenbereich bearbeitet. Das kann sichtbare Kanten verringern, verhindert Minecraft-Fluessigkeitsspruenge nicht sicher.
- `/risingsea status` zeigt Zielpegel, offene Chunks und seit Serverstart platzierte Wasserbloecke. `debug` kann als Diagnose-Einstellung geschaltet werden.
- Lokale Standardkonfiguration ist auch im Mod-Menu-Hauptmenue anzeigbar und dort speicherbar. Im Spiel sind die **Serverwerte verbindlich**; auf dedizierten Servern wirken lokale Hauptmenue-Defaults nicht.
- Bei steigendem Meeresspiegel werden ausschliesslich geeignete bestehende Boote angehoben; beim Absenken uebernimmt Vanilla die Bootsphysik. Andere Entities werden nicht extra versetzt.

## Konsolenbeispiele

```text
risingsea set randomschedule true
risingsea set randommindays 1
risingsea set randommaxdays 5
risingsea set waitscan true
risingsea set debug true
risingsea status
risingsea setlevel 75
risingsea mode tsunami
risingsea set tsunamidays 3
```

## Build

Unter Windows CMD im Ordner mit `build.gradle`:

```bat
set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-25.0.5.8-hotspot" && set "PATH=C:\Program Files\Eclipse Adoptium\jdk-25.0.5.8-hotspot\bin;%PATH%" && gradle --stop && gradle clean build
```

Erwartete JAR bei erfolgreichem Build: `build/libs/risingsea-6.4.jar`.

## Test und Grenzen

Dies ist **Quellcode** und keine getestete JAR. Vor dem Einsatz eine Welt sichern. Globaler Zielwert heisst nicht, dass alle ungeladenen Chunks sofort veraendert werden. Das Rueckbau-Ledger erfasst nur vom Mod gesetzte Wasserbloecke. TSUNAMI und Vanilla-Fluessigkeitsphysik koennen Wasser ueber die gespeicherten Positionen hinaus verteilen. Die experimentelle Wellenbereinigung ist weiterhin nicht zuverlaessig vollstaendig. Falling Sea und Rising Sea nicht gleichzeitig in derselben Welt zum Bearbeiten von Wasserstaenden einsetzen.

Die Basis fuer die Chunk-Rand-Reihenfolge, Scan-Barriere und persistente Random-Intervalle wurde anhand der vom Nutzer bereitgestellten Falling Sea v1.22-Quellen angepasst. Die Funktionen werden nicht 1:1 uebertragen, weil Entfernen von Wasser und Hinzufuegen von Wasser unterschiedliche Nebenwirkungen erzeugen.


## Languages / Sprachen
GUI, HUD effect, and key server/chat messages are translated to English and German
through `assets/risingsea/lang/en_us.json` and `de_de.json`. Language follows Minecraft client settings.

## Rising Sea status-effect-style HUD
A compact effect-like countdown appears in the upper right during the final warning seconds
when a rise is pending, flooding is active and chunk processing is ready. This is a HUD element,
not a potion effect; it does not alter player attributes. It is updated via server snapshots.

## Icon
`assets/risingsea/icon.png`: upward arrows above seawater, opposite direction from Falling Sea.

## Countdown (v1.68)

- Only the upper-right effect tile is shown; the redundant actionbar countdown was removed.
- `countdownLastSeconds` sets the *start of the warning window* (0-60 seconds), not the interval between events.
- `intervalSeconds` governs regular rise in LAYERS/REALISTIC. TSUNAMI uses `tsunamiIntervalDays` (Minecraft days); 0 means manual only.
- Manual-only tsunami reports `manual` in `/risingsea status` and never displays an absurd countdown.
- While the next rising step is waiting for a chunk pass, the effect tile is suppressed to avoid a frozen countdown.

For 60 seconds of advance notice, configure `countdownLastSeconds=60`. To trigger a tsunami automatically use `tsunamiIntervalDays>=1`; normal `intervalSeconds=60` does not override the tsunami day timer.

## Tsunami-Wellenfront (v1.68)

Der Tsunami wird als wandernde ringfoermige Front mit Partikeln und einer begrenzten Zahl zusaetzlicher temporaerer Wasserquellen simuliert. Die Quellen werden nur in bereits geladenen Chunks und nur in Luftpositionen oberhalb des aktuellen Meeresspiegels gesetzt. Ein zeitbasierter Bereinigungsauftrag soll sie nach dem Wellendurchgang entfernen. Bei einem Crash werden aufgezeichnete Quellen beim naechsten Weltstart erneut zur Bereinigung eingeplant.

**Wichtig:** Minecraft kann aus den temporaeren Wasserquellen weiteres, nicht protokolliertes Fliesswasser erzeugen. Die Ruecknahme ist daher nur ein Best-Effort-Verfahren und **keine Garantie**, dass der Ursprungszustand vollstaendig wiederhergestellt wird. Die Wellenfront ist keine vollstaendige Stroemungs- oder Physiksimulation. In aelteren Welten verbliebenes Wasser aus frueheren Versionen kann nicht automatisch identifiziert werden. Verwende eine frische, gesicherte Testwelt.

## Tsunami (experimental) in v1.68

- `permanentSeaLevelRise=false` (`/risingsea set permanent false`): traveling temporary wave with no persistent sea-level change. The ordinary base sea level remains unchanged.
- `permanentSeaLevelRise=true`: traveling wave plus persistent global target rise.
- `liftBoatsWithSeaLevel=true` (`/risingsea set boatlift true`): lift eligible boats, with passengers, once when the normal sea target rises. This does not move mobs, dropped items, or swimmers. Turning this off disables the boat lift. Lowering remains under vanilla buoyancy/gravity control for safety.
- A capped set of temporary wave-water blocks is recorded in `risingsea-temporary-wave.dat.gz`. Cleanup is retried when chunks reload; old records from a crash are restored and cleaned. Natural water and structures are not intentionally overwritten. Minecraft fluid propagation can still leave untracked flowing water. **This is experimental and does not guarantee perfect rollback**. Use a disposable test world.
- Tsunami intervals use `tsunamiIntervalDays`, with `0` meaning manual only.


## Hinweise zu v1.68

* Bootsrettung: periodische, auf Boote begrenzte Nachkorrektur, wenn der globale Pegel bereits angehoben wurde und das Boot nach der Chunk-Verarbeitung unter mod-eigenem Wasser feststeckt. Abschaltbar mit `risingsea set boatlift false`.
* Beim temporären Tsunami wird die Rücknahme jetzt mit Nachbaraktualisierung durchgeführt und die Anzahl gleichzeitig platzierter Quellen begrenzt. **Ein vollständig zuverlässiger physischer Rückbau ist mit Vanilla-Wasserquellen weiterhin nicht garantiert.**
* Dauerhafte Wasserstände aus früheren Testversionen werden nicht automatisch zurückgesetzt. `risingsea setlevel 63` ist ein separater Vorgang und betrifft nur Wasser, das im Ledger als mod-eigen erfasst ist.
* Für echte zeitlich begrenzte Wellen ohne Nachlaufwasser ist langfristig ein eigenes kontrolliertes Flüssigkeitssystem erforderlich.

Achtung: Noch nicht gegen Minecraft 26.3 kompiliert bzw. im Spiel getestet.

## v1.68 Hinweise

- Die Einstellung heisst kurz `Tsunami dauerhaft` (AN/AUS).
- Die Bootsrettung sucht besetzte Boote regelmaessig, sofern am Zielpunkt bereits eine Wasseroberflaeche und Platz darueber existieren.
- Die Welle beginnt vor dem ausloesenden Spieler und verwendet dichter angeordnete Wasser- und Partikelpositionen.
- **Experimentell:** Minecraft kann Wasser selbststaendig ausbreiten. Vollstaendig rueckstandsfreie physische Wellen sind dadurch weiterhin nicht garantiert.


## v1.68: Boats and sealed buildings

The permanent flood fills water blocks up to Y = target, so the *surface* is
at Y = target + 1. The boat relocation now targets that upper surface and no
longer requires water to be present at the boat's old position. It moves only
occupied boats eligible for sea-level correction, if the destination is clear.

Normal chunk flooding now requires sky access or a directly adjacent water
connection before filling any air block, across all modes. Completely sealed
rooms therefore should not be filled from the inside. Open doors, holes, or
other wet connections can still allow water to enter. This is NOT a guarantee
that every large cave/structure will drain correctly, especially if an older
release has already placed water there. Temporary tsunami water is still
experimental; Minecraft may create additional flowing water not in the ledger.

Test in a freshly created world. Existing mod-created water from old versions
remains in saved chunks unless explicitly removed using a suitable backup.
