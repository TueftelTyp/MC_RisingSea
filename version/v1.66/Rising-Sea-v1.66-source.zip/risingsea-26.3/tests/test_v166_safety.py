import pathlib
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCE=(ROOT/'src/main/java/de/risingsea/RisingSea.java').read_text()

class SafetyRegression(unittest.TestCase):
    def test_only_boats_rescued(self):
        body=SOURCE.split('private void rescueSubmergedBoats(',1)[1].split('private boolean isAtWave',1)[0]
        self.assertIn('AbstractBoat.class',body)
        self.assertNotIn('ItemEntity',body)
        self.assertNotIn('Mob.class',body)
        self.assertIn('gameTicks % 10',body)

    def test_rescue_requires_owned_water(self):
        body=SOURCE.split('private void rescueSubmergedBoats(',1)[1].split('private boolean isAtWave',1)[0]
        for check in ('worker.ownsWater(surface)', 'world.noCollision(', 'world.getFluidState(surface)', 'boat.setPos('):
            self.assertIn(check,body)

    def test_cleanup_notifies_neighbors(self):
        body=SOURCE.split('void cleanupOnly(',1)[1].split('private void discover(',1)[0]
        self.assertIn('world.setBlock(pos, Blocks.AIR.defaultBlockState(), 3)',body)

    def test_version(self):
        self.assertIn('mod_version=1.66',(ROOT/'gradle.properties').read_text())

if __name__=='__main__': unittest.main()
