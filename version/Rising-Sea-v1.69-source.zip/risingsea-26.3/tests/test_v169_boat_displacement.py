import pathlib
import subprocess
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = (ROOT/'src/main/java/de/risingsea/RisingSea.java').read_text()

class BoatShiftTests(unittest.TestCase):
    def test_direct_one_time_shift(self):
        self.assertIn('if (boatObservedLevel != save.level)', SRC)
        self.assertIn('moveBoatsForSeaRise(server, boatObservedLevel, save.level)', SRC)
        self.assertIn('boat.setPos(boat.getX(), newY, boat.getZ())', SRC)
        self.assertNotIn('rescueSubmergedBoats(', SRC)
        self.assertNotIn('processBoatTransfers(', SRC)

    def test_passengers_and_other_entities_untouched(self):
        method = SRC.split('private void moveBoatsForSeaRise(',1)[1].split('private void tickRaisedBoats(',1)[0]
        self.assertIn('AbstractBoat.class', method)
        self.assertNotIn('ejectPassengers()',method)
        self.assertNotIn('ItemEntity',method)

    def test_hold_released(self):
        self.assertIn('boat.setNoGravity(true)',SRC)
        self.assertIn('boat.setNoGravity(false)',SRC)
        self.assertIn('releaseRaisedBoats(server)',SRC)

    def test_version(self):
        self.assertIn('mod_version=1.69',(ROOT/'gradle.properties').read_text())

    def test_pure_policy(self):
        with tempfile.TemporaryDirectory() as t:
            policy = ROOT/'src/main/java/de/risingsea/BoatLiftPolicy.java'
            runner = pathlib.Path(t)/'Check.java'
            runner.write_text('''import de.risingsea.BoatLiftPolicy;
public class Check { public static void main(String[] args) {
if (Math.abs(BoatLiftPolicy.targetHeight(64.1, 2, 65) - 66.1) > 0.0001) throw new AssertionError();
if (BoatLiftPolicy.targetHeight(60, 2, 65) < 66.08) throw new AssertionError();
if (BoatLiftPolicy.targetHeight(64, -1, 63) != 64) throw new AssertionError();
}}
''')
            subprocess.run(['javac','-d',t,str(policy),str(runner)],check=True)
            subprocess.run(['java','-cp',t,'Check'],check=True)

if __name__ == '__main__': unittest.main()
