import pathlib
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCE=(ROOT/'src/main/java/de/risingsea/RisingSea.java').read_text()
POLICY=(ROOT/'src/main/java/de/risingsea/BoatLiftPolicy.java').read_text()

class Regression(unittest.TestCase):
    def test_boat_relocation_above_water_top(self):
        self.assertIn('BoatLiftPolicy.targetHeight(', SOURCE)
        self.assertIn('world.noCollision(boat, boat.getBoundingBox().move(', SOURCE)
    def test_old_rescue_removed(self):
        self.assertNotIn('private void rescueSubmergedBoats(', SOURCE)
        self.assertIn('private void moveBoatsForSeaRise(', SOURCE)
    def test_solid_roof_stays_dry(self):
        self.assertIn('boolean exposed = level.canSeeSky(pos);', SOURCE)
        self.assertIn('boolean fill = exposed || (cfg.floodCaves && connected);', SOURCE)
        self.assertNotIn('boolean fill = !"REALISTIC".equals(cfg.floodMode) || hasWetNeighbor(level, pos);', SOURCE)
    def test_no_generic_entity_teleports(self):
        self.assertNotIn('ItemEntity.class',SOURCE)
    def test_version(self):
        self.assertIn('mod_version=1.69',(ROOT/'gradle.properties').read_text())

if __name__ == '__main__': unittest.main()
