import pathlib
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCE=(ROOT/'src/main/java/de/risingsea/RisingSea.java').read_text()

class SafetyRegression(unittest.TestCase):
    def test_only_boats_shifted(self):
        body=SOURCE.split('private void moveBoatsForSeaRise(',1)[1].split('private void tickRaisedBoats(',1)[0]
        self.assertIn('AbstractBoat.class',body)
        self.assertNotIn('ItemEntity',body)
        self.assertNotIn('Mob.class',body)
    def test_shift_requires_safe_target(self):
        body=SOURCE.split('private void moveBoatsForSeaRise(',1)[1].split('private void tickRaisedBoats(',1)[0]
        for check in ('world.noCollision(', 'BoatLiftPolicy.targetHeight(', 'boat.setPos('):
            self.assertIn(check,body)
    def test_cleanup_notifies_neighbors(self):
        body=SOURCE.split('void cleanupOnly(',1)[1].split('private void discover(',1)[0]
        self.assertIn('world.setBlock(pos, Blocks.AIR.defaultBlockState(), 2)',body)

    def test_version(self):
        self.assertIn('mod_version=1.69',(ROOT/'gradle.properties').read_text())

if __name__=='__main__': unittest.main()
