import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SERVER=(ROOT/'src/main/java/de/risingsea/RisingSea.java').read_text()
GUI=(ROOT/'src/main/java/de/risingsea/client/RisingSeaConfigScreen.java').read_text()
class NewFeatures(unittest.TestCase):
    def test_sea_level_unchanged_for_temporary_wave(self):
        self.assertIn('if (config.permanentSeaLevelRise) save.level = save.waveDestinationLevel;',SERVER)
        self.assertIn('? Math.min(config.maxWaterLevel, save.level + rise) : save.level;',SERVER)
    def test_temporary_cleanup_is_persistent(self):
        self.assertIn('loadTemporary(temporaryWaveFile)',SERVER)
        self.assertIn('saveTemporary(temporaryWaveFile)',SERVER)
        self.assertIn('if (pos.getY() > save.level && world.getBlockState(pos).is(Blocks.WATER))',SERVER)
    def test_boat_setting_is_toggable_server_and_gui(self):
        self.assertIn('case "boatlift"', SERVER)
        self.assertIn('moveBoatsForSeaRise(server, boatObservedLevel, save.level)', SERVER)
        self.assertIn('Map.entry("boatlift", "liftBoatsWithSeaLevel")', GUI)
    def test_no_any_entity_transport(self):
        self.assertNotIn('ItemEntity.class',SERVER)
        self.assertIn('boat.setPos(boat.getX(), newY, boat.getZ());',SERVER)
    def test_wave_does_not_replace_natural_blocks(self):
        self.assertIn('!world.getBlockState(pos).isAir()',SERVER)
        self.assertIn('temporaryOwned.containsKey(key)',SERVER)
    def test_no_overlapping_tsunamis(self):
        self.assertIn('if (save.waveActive) return;',SERVER)
if __name__=='__main__': unittest.main()
