package de.risingsea;

/** Pure, side-effect-free rules for sea-level boat displacement. */
public final class BoatLiftPolicy {
    private BoatLiftPolicy() {}

    public static boolean nearOldSurface(double boatY, int seaLevel) {
        return Double.isFinite(boatY) && Math.abs(boatY - (seaLevel + 1.0)) <= 2.0;
    }

    public static double targetHeight(double currentY, int rise, int newSeaLevel) {
        if (!Double.isFinite(currentY) || rise <= 0) return currentY;
        // The upper face of the highest water block lies at Y=level+1.
        return Math.max(currentY + rise, newSeaLevel + 1.08);
    }
}
